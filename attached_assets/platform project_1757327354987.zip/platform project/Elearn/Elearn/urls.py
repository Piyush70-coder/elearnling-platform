from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),

    # Basic Pages
    path('base/', views.BASE, name='base'),
    path('contact/', views.CONTACT, name='contact'),

    # Authentication
    path('login/', views.LOGIN, name='login'),
    path('logout/', views.LOGOUT, name='logout'),
    path('signup/', views.SIGNUP, name='signup'),

    # Django’s built-in auth urls (password reset etc.)
    path('accounts/', include('django.contrib.auth.urls')),

    # Live Code Runner
    path('code-runner/', views.code_runner, name='code_runner'),
    path('run-code/', views.RUN_CODE, name='run_code'),
]

# ✅ Serve uploaded media (videos/images) during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
