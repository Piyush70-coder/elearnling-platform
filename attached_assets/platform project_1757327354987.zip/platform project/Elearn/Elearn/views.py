from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import requests
import json
from django.shortcuts import render
from Krish.models import Category, Course

def BASE(request):
    categories = Category.objects.all()
    courses = Course.objects.filter(is_featured=True)  # only featured

    context = {
        "categories": categories,
        "courses": courses,
    }
    return render(request, "registration/base.html", )

def CONTACT(request):
    return render(request, 'main/contact.html')

# =============================
# Authentication
# =============================
def LOGIN(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f"Welcome back {user.username}!")
            return redirect("base")
        else:
            messages.error(request, "Invalid username or password")
            return redirect("login")

    return render(request, "main/login.html")

def LOGOUT(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("login")

def SIGNUP(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password1 = request.POST.get("password1")
        password2 = request.POST.get("password2")

        if password1 != password2:
            messages.error(request, "Passwords do not match.")
            return redirect("signup")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return redirect("signup")

        user = User.objects.create_user(username=username, email=email, password=password1)
        user.save()
        messages.success(request, "Account created successfully! Please login.")
        return redirect("login")

    return render(request, "main/signup.html")

# =============================
# Judge0 API - Live Code Runner
# =============================
JUDGE0_API_URL = "https://judge0-ce.p.rapidapi.com/submissions"

# ⚠️ Replace with your RapidAPI key
JUDGE0_HEADERS = {
    "x-rapidapi-host": "judge0-ce.p.rapidapi.com",
    "x-rapidapi-key":"891f8301b6msh756ed03b1163048p17f92ajsn072361cb71a8",


    "content-type": "application/json",
}

# Language IDs (Judge0)
LANGUAGES = {
    "python": 71,   # Python 3
    "cpp": 54,      # C++ (GCC 9.2.0)
    "java": 62      # Java (OpenJDK 13)
}

@csrf_exempt
def RUN_CODE(request):
    if request.method == "POST":
        data = json.loads(request.body)
        source_code = data.get("code")
        language = data.get("language", "python")

        if language not in LANGUAGES:
            return JsonResponse({"error": "Unsupported language"}, status=400)

        payload = {
            "source_code": source_code,
            "language_id": LANGUAGES[language],
            "stdin": data.get("stdin", "")
        }

        # Submit code
        response = requests.post(JUDGE0_API_URL + "?base64_encoded=false&wait=true",
                                 headers=JUDGE0_HEADERS,
                                 data=json.dumps(payload))

        return JsonResponse(response.json())

    return JsonResponse({"error": "POST request required"}, status=400)
def code_runner(request):
    return render(request, "main/coderunner.html")