from django.contrib import admin
from django.utils.html import format_html
from .models import Category, Course


# Inline courses inside Category
class CourseInline(admin.TabularInline):   # or StackedInline if you prefer big form
    model = Course
    extra = 0
    fields = ("title", "level", "is_featured")
    show_change_link = True


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "created_at", "updated_at")
    search_fields = ("name",)
    ordering = ("name",)
    inlines = [CourseInline]   # 👈 allows adding/editing Courses inside Category


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    # Thumbnail for image
    def thumbnail(self, obj):
        if obj.image:
            return format_html(
                '<img src="{}" width="60" height="40" style="object-fit:cover; border-radius:6px;" />',
                obj.image.url
            )
        return "—"
    thumbnail.short_description = "Image"

    # ✅ Video preview
    def video_preview(self, obj):
        if obj.video:
            return format_html(
                '<video width="120" height="70" controls>'
                '<source src="{}" type="video/mp4">'
                'Your browser does not support the video tag.'
                '</video>',
                obj.video.url
            )
        return "—"
    video_preview.short_description = "Video"

    list_display = (
        "thumbnail", "title", "category", "level",
        "rating", "is_featured", "video_preview", "created_at"
    )
    list_filter = ("category", "level", "is_featured", "created_at")
    search_fields = ("title", "description")
    ordering = ("-created_at",)
    date_hierarchy = "created_at"
    list_display_links = ("title",)  # make only title clickable
    list_editable = ("is_featured", "level")  # quick edit directly in list view

    # Admin actions
    @admin.action(description="Mark selected as featured")
    def make_featured(self, request, queryset):
        queryset.update(is_featured=True)

    @admin.action(description="Unmark selected as featured")
    def make_unfeatured(self, request, queryset):
        queryset.update(is_featured=False)

    actions = ["make_featured", "make_unfeatured"]
