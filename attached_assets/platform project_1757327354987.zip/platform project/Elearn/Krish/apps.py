from django.apps import AppConfig


class KrishConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Krish'
