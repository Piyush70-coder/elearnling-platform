# models.py
from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ['name']

    def __str__(self):
        return self.name


class Course(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="courses")
    title = models.CharField(max_length=200)
    description = models.TextField()
    image = models.ImageField(upload_to="courses/", blank=True, null=True)  # ✅ for thumbnails
    level = models.CharField(max_length=50, default="Beginner")             # ✅ Beginner/Intermediate/Advanced
    rating = models.DecimalField(max_digits=2, decimal_places=1, default=4.5)  # e.g. 4.5★
    duration = models.CharField(max_length=50, default="2h 30m")            # ✅ e.g. "3h 20m"
    lessons = models.PositiveIntegerField(default=10)                       # ✅ no. of lessons
    is_featured = models.BooleanField(default=False)                        # ✅ for homepage
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    video = models.FileField(upload_to="course_videos/", blank=True, null=True)

    def __str__(self):
        return self.title
